namespace Lex
{
/*
 * Class: NfaPair
 */
public class NfaPair
{
/*
 * Member Variables
 */
public Nfa start;
public Nfa end;
  
/*
 * Function: NfaPair
 */
public NfaPair()
  {
  start = null;
  end = null;
  }
}
}
